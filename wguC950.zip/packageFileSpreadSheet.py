"""
This will output 'WGUPS Package File.xlsx' information into python

"""

"""read as a csv file"""

import csv
def loadPackage():
    packageList = []
    with open('WGUPS Package File.csv') as csvfile:
        csvReader = csv.reader(csvfile, delimiter=",")
        for row in csvReader:
            packageList.append(row)

    return packageList
