"""extracts data from "distanceData" file"""
import csv

def loadDistance():
    distanceList = []
    with open('distanceData.csv') as csvfile:
        csvReader = csv.reader(csvfile, delimiter=",")
        # next(csvReader)
        for row in csvReader:
            distanceList.append(row)

    # for i in distanceList:
    #     print(i)
    return distanceList

"""#loadDistance()"""