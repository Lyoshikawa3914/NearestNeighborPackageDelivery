"""extracts data from "addressAndHub" file"""

import csv
def loadAddresses():
    addressList = []
    with open('AddressNames.csv') as csvfile:
        csvReader = csv.reader(csvfile, delimiter=",")
        for row in csvReader:
            addressList.append(row[2])


    # for i in addressList:
    #      print(i)
    return addressList

"""# loadAddresses()"""


