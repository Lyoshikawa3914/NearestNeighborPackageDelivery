"""class to make truck objects"""

class truckClass:
    def __init__(self, packageList=[], lefttime=None):
        self.time = lefttime
        self.capacity = 0
        self.packageList = packageList
        self.leftTime = lefttime
        self.mileage = 0



    def totalCapacity(self):
        return self.capacity

    def showPackages(self):
        return self.packageList

    def setDepartTime(self, myHash):
        for pkg in self.packageList:
            package = myHash.search(pkg)
            package.departTime = self.time
            package.deliveryStatus = 'enroute'











