import csv

class packageClass2:
    def __init__(self, id, address, deadline,
                 city, zip, weight, deliveryStatus = "At hub", departTime = None):
        self.id = id
        self.address = address
        self.deadline = deadline
        self.city = city
        self.zip = zip
        self.weight = weight
        self.deliveryStatus = deliveryStatus
        self.departTime = departTime

        self.deliveryTime = None

    def __str__(self):  # overwite print(package) otherwise it will print object reference
        return "ID: %s, Address: %s, Deadline: %s, City: %s, Zip: %s, Weight: %s, DeliveryStatus: %s, Depart Time: %s, Delivered Time: %s" % \
               (self.id, self.address, self.deadline, self.city, self.zip,
                                       self.weight, self.deliveryStatus, self.departTime, self.deliveryTime)



def createPackages(myHash):
    with open('WGUPS Package File.csv') as csvfile:
        packages = csv.reader(csvfile, delimiter=",")

        #skips the first row because its the header
        next(packages)

        for package in packages:
            id = int(package[0])
            address = package[1]
            state = package[3]
            deadline = package[5]
            city = package[2]
            zip = package[4]
            weight = package[6]
            deliveryStatus = 'at Hub'


            #creating the package object
            packageObj = packageClass2(id, address, deadline, city, zip, weight, deliveryStatus)

            #print(packageObj)

            #insert package object into the hash table
            myHash.insert(id, packageObj)


