"""
Lawrence Yoshikawa
Student ID: 001204218
"""
import hashTable
import packageClass2
import truckClass
import addressAndHub
import distanceData
import datetime




#getAllAddress = allAddresses.getAddress()

#initialize the hashtable object
myHash = hashTable.ChainingHashTable()

# initilaize the package objects
packageClass2.createPackages(myHash)

# call and load the address from addressAndHub file
addressList = addressAndHub.loadAddresses()
# for i in addressList:
#     print(i)

# call and load the data from distance file
distanceList = distanceData.loadDistance()
# for i in distanceList:
#     print(i)


# testing purposes
# h1 = addressList.index('1060 Dalton Ave S')
# print(h1)
# h2 = addressList.index('1330 2100 S')
# print(h2)
#
# print(distanceList[h2][h1])

# print(addressList.index("1060 Dalton Ave S"))

# startTime = '08:00:00'
# h, m, s = startTime.split(":")
# timeObject = datetime.timedelta(hours=int(h), minutes=int(m), seconds=int(s))


def distanceBetweenAddresses(add1, add2):
    """this function will return distance between address 1 ('add1')
    and address 2 ('add 2')
    the 'addressList.index(add1)' returns the index from the 'add1' input
    """

    index1 = addressList.index(add1)
    index2 = addressList.index(add2)

    """if the distance of add1 and add2 are listed as '' from the distacne file,
    switch and return the distance between add2 and add1
    else: return as is"""
    if distanceList[addressList.index(add1)][addressList.index(add2)] == '':
        return float(distanceList[addressList.index(add2)][addressList.index(add1)])
    else:
        return float(distanceList[addressList.index(add1)][addressList.index(add2)])

def minDistanceFromAddress(address, packages):
    """this fucntion will be called from 'deliveryPackage' function
        Packages contains a list of IDs of the packages

        'myHash.search(package).address' will search 'myHash' hashtable that was
        built using the ID from 'package', then will call the address because
        of the '.address'
    """

    """ create variables 'minDistance', 'nextAddress', and 'nextID'"""
    minDistance = float('inf')
    nextAddress = None
    nextID = None


    """ for each item in the package list, it will call 'distanceBetweenAddresses' function
     and will get a distance from 'add2' with 'address'"""
    for i in range(len(packages)):

        add2 = myHash.search(packages[i]).address
        distance = distanceBetweenAddresses(address, add2)

        """ if statement will determine whether 'distance' is less than 'minDistantce'
         if 'distance' is less than 'minDistance', 'distance' will be the new 'minDistance'"""
        if distance < minDistance:
            minDistance = distance


            nextAddress = add2
            nextID = myHash.search(packages[i])

    return nextAddress, nextID, minDistance

def deliveryPackages(truck):
    miles = 0

    """ the 'currentAddress' holds the starting address
     'currentTime' holds the departure time of the truck object"""


    currentAddress = addressList[0]
    currentTime = truck.leftTime

    while len(truck.packageList) > 0:
        """This is the loop deliver packages from each truck by calling 'minDistanceFromAddress
        return the next ID of package object and updating the time it will be delivered
        while updating the current time
        """

        """ will call 'minDistanceFromAddress' and return 'currentAddress', 'package', and 'minDistance'"""
        currentAddress, package, minDistance = minDistanceFromAddress(currentAddress, truck.packageList)

        """ by dividing 18 (each truck's mph) from 'minDistance', then getting the time traveled"""
        timeTraveled = minDistance/18

        """ 'timeTraveled' will be changed into a datetime object, then will be addedd to 'currentTime'
        'currentTime' will be used to help indicate when a package is delivered"""
        currentTime = currentTime + datetime.timedelta(hours=timeTraveled)

        """ 'currentTime' will be saved into the package's deliveryTime attribute"""
        package.deliveryTime = currentTime

        """ 'minDistance' will be added to truck object to track the amount of miles travelled"""
        truck.mileage += minDistance
        package.deliveryStatus = "Delivered"

        """ once the package is delivered, the package will be removed from 'packageList'"""
        truck.packageList.remove(package.id)
        #print(package)
        #print(currentAddress, currentTime, package)

    return truck.mileage




#print(distanceBetweenAddresses('1488 4800 S', '1330 2100 S'))

""" t1, t2, t3 represents the trucks with the package IDs"""
t1 = [1, 30, 13, 14, 15, 16, 19, 20, 21, 31, 33, 35, 29, 5, 11, 40]
t2 = [3, 6, 18, 25, 34, 36, 37, 38, 26]
t3 = [2, 8, 9, 12, 17,  22, 23, 24, 27, 28, 10, 4, 7, 39, 32]

""" create truck objects, inserting the list of package IDs and departure time
 truck objects will call truckObj.setDepartTime(myHash) to set package objects' departure time"""
truck1 = truckClass.truckClass(t1, datetime.timedelta(hours=8))
truck1.setDepartTime(myHash)
#print(myHash.search(t1[0]))


truck2 = truckClass.truckClass(t2, datetime.timedelta(hours=9, minutes=5))
truck2.setDepartTime(myHash)
#print(myHash.search(t2[0])

truck3 = truckClass.truckClass(t3, datetime.timedelta(hours=10, minutes=30))
truck3.setDepartTime(myHash)

""" calls 'deliveryPackages' for each truck object and returns each truck objects' mileage"""
truck1Miles = deliveryPackages(truck1)
truck2Miles = deliveryPackages(truck2)
truck3Miles = deliveryPackages(truck3)

totalMileage = truck1Miles + truck2Miles + truck3Miles
print()
print("The total mileage of all trucks is " + str(round(totalMileage, 2)))



# print(truck1.mileage)
# print(truck2.mileage)
# print(truck3.mileage)
print()

# print(distanceBetweenAddresses(addressList.index('4001 South 700 East'),
#                                addressList.index('1060 Dalton Ave S')))

#myHash.showAll()


print("Welcome to WGUPS. What would you like to see? \n"
      "Type the number to get the info. Type 'quit' to exit the application")

print("")
userInput = input("1) Get package info (Type '1')"
                  "\nType 'quit' to exit application \n")

while userInput:

    if userInput == 'quit' or userInput == 'Quit':
        print("You quit the program")
        break

        """This section is a dialogue tree that will guide user to select any choice related to packages"""
    elif userInput == str(1):
        while userInput:
            userInput = input("How would you like to view information?"
                              "\n Type the number to get the info. "
                              "\n 1) A single package at a specific time"
                              "\n 2) All packages at a specific time"
                              "\n 3) All package information with total truck mileage\n"
                              "\n Back) Type 'back' to go back to main menu\n")


            if userInput == 'back' or userInput == 'Back':
                print('Returning to main menu \n')
                break

            elif userInput == str(1):
                packageInput = int(input("Type the ID of package. (Package ID range 1-40)"))

                while packageInput:
                    """ the prompt will ask to retype the ID if the number isn't in range
                     from 1-40"""
                    if int(packageInput) not in range(1, 41):
                        packageInput = input("Please type a number in range of 1-40")

                    elif int(packageInput) in range(1, 41):
                        packageTime = input("What time? (hh:mm)")

                        """ will split 'packageTime' into 'h' and 'm'"""
                        h, m = packageTime.split(':')
                        timeObject = datetime.timedelta(hours=int(h), minutes=int(m), seconds=0)
                        #print(timeObject)



                        """ searching for the package object in the hashTable and outputing it"""
                        package = myHash.search(int(packageInput))

                        """ if the user selects package 9 and entered 10:20 or after, package 9's address will update"""
                        if packageInput == int(9) and int(h) >= 10 and int(m) >= 20:
                            package.address = "410 S State St"

                        if package.departTime > timeObject:
                            print("Package " + str(package.id) + " will be delivered to " + package.address +
                                  " by " + str(package.deadline) + ". Status: At hub."
                                  )

                        elif package.deliveryTime < timeObject:
                            print("Package " + str(package.id) + " was delivered at " + str(package.deliveryTime) +
                                  "." + " Departed at " + str(package.departTime) + ". Package Deadline is " +
                                  str(package.deadline) + '. Status: Delivered')

                        else:
                            print("Package " + str(package.id) + " left hub at " + str(package.departTime)
                                  + ' Will arrive at ' + str(package.address) + ' Status: Enroute')


                        # print("\n Package " + str(packageInput) + " was delivered to " + package.address + " at "
                        #       + str(package.deliveryTime) + " " + package.deliveryStatus)


                        """ the program will ask what they want to do after getting there information"""
                        userInput = input("\n What would you like to do? \n"
                                             "Yes) Select another package \n"
                                             "Main) Go back to main menu \n")

                        if userInput == "Yes" or userInput == 'yes':

                            """ if package 9 was selected with a time of 10:20 or later, revert the time back to '300 State St'"""
                            if packageInput == int(9) and int(h) >= 10 and int(m) >= 20:
                                package.address = "300 State St"
                            break
                        if userInput == "Main" or userInput == 'main':

                            """ if package 9 was selected with a time of 10:20 or later, revert the time back to '300 State St'"""
                            if packageInput == int(9) and int(h) >= 10 and int(m) >= 20:
                                package.address = "300 State St"
                            break
                        else:
                            userInput = input("You typed something else. Please type again \n")

                    else:
                        packageInput = input("You typed something else. Please type again \n")

                if userInput == "Main":
                    break

            elif userInput == str(2):
                startTimeInput = input("From what time? (hh:mm)")
                startH, startM = startTimeInput.split(":")

                startTimeObject = datetime.timedelta(hours=int(startH), minutes=int(startM), seconds=0)

                #add address, deadline
                for i in range(len(myHash.table)):
                    pkg = myHash.search(i)
                    if pkg == None:
                        continue
                    #print(pkg)
                    if (startTimeObject < pkg.departTime):
                        print("Package " + str(pkg.id) + " will depart at " + str(pkg.departTime) + " Status: at hub" +
                              " will arrive by " + str(pkg.deadline))
                        # if (pkg[0][1].deliveryTime >= endTimeObject):
                    elif startTimeObject >= pkg.deliveryTime:
                        print("Package " + str(pkg.id) + " departed at " + str(pkg.departTime) + " Deadline was " +
                              str(pkg.deadline) + " Status: Delivered. "
                              + str(pkg.deliveryTime))
                    else:
                        print("Package " + str(pkg.id) + " departed at " + str(pkg.departTime) + " Status: Enroute. " +
                              ". Will arrive by " + str(pkg.deadline))

            elif userInput == str(3):
                for i in range(len(myHash.table)):
                    pkg = myHash.search(i)
                    if pkg == None:
                        continue
                    if pkg.id == 9:
                        pkg.address = "410 S State St"
                    print(str(pkg) + "\n")
                    if pkg.id == 9:
                        pkg.address = "300 State St"
                print("\nThe total miles of all trucks is " + str(round(totalMileage, 2)) + "\n")



            else:
                userInput = input("You typed something else. Please type again")

    print("Welcome to WGUPS. What would you like to see? \n"
          "Type the number to get the info. Type 'quit' to exit the application \n")

    userInput = input("1) Get package info "
                      "\nType 'quit' to exit application \n")




if userInput == 'quit' or userInput == 'Quit':
    exit()

